Lab 5: Static Code Analysis — Reflection

## 1. What is the importance of static code analysis?

Static code analysis examines source code without executing it. It helps identify programming mistakes, security vulnerabilities, and coding-style violations early in development. This improves code quality, security, readability, and maintainability.

## 2. What did you learn from Pylint, Bandit, and Flake8?

Pylint helped identify code-quality issues, naming violations, missing docstrings, and potential programming problems. Bandit detected potentially unsafe coding patterns, including shell command execution and unsafe pickle deserialization. Flake8 identified formatting problems such as incorrect indentation, whitespace, and excessive blank lines.

## 3. What challenges did you face while fixing the issues?

I faced challenges understanding the warnings reported by the tools and correcting indentation, naming conventions, and security-related code. I resolved these issues by modifying the code, rerunning the tools, and checking that the task manager continued to work correctly.

## 4. How does static code analysis contribute to software quality?

Static code analysis helps developers detect problems before execution or deployment. Using multiple tools provides complementary checks for code quality, security, and formatting. In this lab, I improved the task manager and verified the changes with repeated analysis, achieving a Pylint score of 10.00/10 and a clean Bandit scan.
