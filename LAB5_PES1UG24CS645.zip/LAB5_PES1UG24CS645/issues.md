| Issue | Type | Line(s) | Description | Fix Approach |

| Shell command injection (B605) | Security - High | 57 | os.system concatenates an email address into a shell command | Replace shell execution with a safer approach |
| Unsafe deserialization (B301) | Security - Medium | 47 | pickle.load can execute malicious code from untrusted files | Replace pickle persistence with JSON |
| Pickle import (B403) | Security - Low | 3 | Importing pickle introduces unsafe deserialization concerns | Remove pickle dependency |
| Mutable default argument (W0102) | Bug | 11 | A shared list is used as a default argument | Use None and initialize a fresh list |
| Inconsistent return (R1710) | Code quality | 33-36 | findTask has no explicit return when no match is found | Add return None |
| Incorrect naming (C0103) | Style | Multiple | Functions and variables do not follow snake_case | Rename identifiers |
| Missing docstrings (C0114/C0116) | Documentation | Multiple | Module and functions lack documentation | Add concise docstrings |
| Missing whitespace (E225/E231) | Formatting | 12, 74 | Operators and commas have incorrect spacing | Add required spaces |
| Blank lines and comment spacing (E303/E261) | Formatting | 40, 69 | Extra blank lines and incorrect inline comment spacing | Correct PEP 8 formatting |