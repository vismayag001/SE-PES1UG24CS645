"""A simple task manager demonstrating static code analysis best practices."""
import json
import secrets
from datetime import datetime

tasks = {}
PRIORITY_ORDER = {"high": 0, "medium": 1, "low": 2}

def add_task(title, priority="medium", labels=None):
    """Add a task and return its ID."""
    if labels is None:
        labels = []

    task_id = len(tasks) + 1
    labels.append(priority)
    tasks[task_id] = {
        "title": title,
        "priority": priority,
        "done": False,
        "created": datetime.now().isoformat(),
        "labels": labels,
    }
    return task_id


def complete_task(task_id):
    """Mark a task as complete if it exists."""
    if task_id in tasks:
        tasks[task_id]["done"] = True
        return True

    print("No task with id", task_id)
    return False


def pending_tasks():
    """Return pending task titles ordered by priority."""
    pending = [
        task for task in tasks.values()
        if not task["done"]
    ]
    pending.sort(
        key=lambda task: PRIORITY_ORDER[task["priority"]]
    )
    return [task["title"] for task in pending]


def find_task(keyword):
    """Return the ID of the first task matching a keyword."""
    for task_id, task in tasks.items():
        if keyword.lower() in task["title"].lower():
            return task_id
    return None


def save_tasks(file_name="tasks.json"):
    """Save tasks to a JSON file."""
    with open(file_name, "w", encoding="utf-8") as task_file:
        json.dump(tasks, task_file, indent=2)


def load_tasks(file_name="tasks.json"):
    """Load tasks from a JSON file and return them."""
    with open(file_name, "r", encoding="utf-8") as task_file:
        loaded_tasks = json.load(task_file)

    return {
        int(task_id): task
        for task_id, task in loaded_tasks.items()
    }


def export_json(file_name="tasks.json"):
    """Export tasks to a JSON file."""
    with open(file_name, "w", encoding="utf-8") as task_file:
        json.dump(tasks, task_file, indent=2)


def main():
    """Run a demonstration of the task manager."""
    tasks.clear()

    add_task("Submit lab report", "high")
    add_task("Buy groceries")
    add_task("Call plumber", "low")
    add_task("Book train tickets", "high")

    complete_task(2)
    complete_task(99)

    print("Pending tasks:", pending_tasks())
    print("Task id for 'plumber':", find_task("plumber"))
    print("Task id for 'gym':", find_task("gym"))

    pending = pending_tasks()
    if pending:
        suggestion = secrets.choice(pending)
        print("Try this next:", suggestion)
    else:
        print("No pending tasks available.")

    save_tasks()
    restored = load_tasks()
    print("Tasks restored from file:", len(restored))

    export_json()
    print("Exported tasks to tasks.json")


if __name__ == "__main__":
    main()
